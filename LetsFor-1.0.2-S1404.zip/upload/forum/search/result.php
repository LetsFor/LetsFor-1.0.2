<?php
require_once ($_SERVER['DOCUMENT_ROOT'] . '/LFcore/core.php');
require_once ($_SERVER['DOCUMENT_ROOT'] . '/forum/search/all_res.php');
