<?
require_once ($_SERVER['DOCUMENT_ROOT'] . '/LFcore/core.php');
