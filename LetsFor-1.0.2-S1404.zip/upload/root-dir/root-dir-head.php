<?
require_once ($_SERVER['DOCUMENT_ROOT'] . '/root-dir/root-dir-core.php');
require_once ($_SERVER['DOCUMENT_ROOT'] . '/LFcore/head.php');
