<?php
require_once ($_SERVER['DOCUMENT_ROOT'].'/root-dir/root-dir-head.php');
header('Location: '.homeLink().'');
exit();
?>