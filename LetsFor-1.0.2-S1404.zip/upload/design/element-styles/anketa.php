<?
echo '<style>
.bbimg {
max-height: 450px;
max-width: 100%
}

.content {
padding: 0px 0px;
background: none;
display: block;
}

.teg {
margin-top: 13px;
border-radius: var(--all-border-radius);
background: var(--theme-color);
}

.menu_tad {
background: var(--theme-color);
margin-top: 15px;
border-radius: var(--all-border-radius);
padding: 10px 15px 11px;
position: relative;
}

textarea[type="pole"] {
	border: 1px solid var(--all-border-color);
}
</style>';
?>