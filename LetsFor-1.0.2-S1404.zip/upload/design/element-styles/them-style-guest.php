<?
echo '<style>
.menu_tad {
	display: none;
}
.no_reg {
	padding: 10px 10px 12px;
	color: #d6d6d6;
	display: block;
	border-top: 1px solid #303030;
}
.d_menu_inus {
	display: none;
}
a.log_nt {
	display: none;
}
a.log_nt_reg {
background: #c33929;
color: #ececee; 
padding: 5px 10px; 
border-radius: 6px;
-webkit-transition: all linear 0.28s;
display: inline-block;
}
a.log_nt_reg:hover {
background-color: #fc3e27; 
}
.action_teme_us {
	display: none;
}
.head_bar_menu {
	display: none;
}
.tema_vis {
	border-radius: 10px 10px 10px 10px;
}
</style>';

?>