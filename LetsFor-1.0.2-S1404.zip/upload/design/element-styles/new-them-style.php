<?
echo '<style>
.content {
	padding: 0px;
	margin: 0px;
}
.menu_bb {
	margin: 0 15px -25px;
}
.teg {
	display: block;
}
@media all and (min-width: 1025px){
#sidebar {
	display: none;
}
.back_but_link {
	display: inline-block;
}
}
</style>';
?>