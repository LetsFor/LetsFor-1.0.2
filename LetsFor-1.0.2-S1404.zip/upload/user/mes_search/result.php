<?php
require_once($_SERVER['DOCUMENT_ROOT'] . '/LFcore/core.php');
require_once($_SERVER['DOCUMENT_ROOT'] . '/user/mes_search/all_res.php');
