<?php
require_once($_SERVER['DOCUMENT_ROOT'] . '/LFcore/core.php');
require_once($_SERVER['DOCUMENT_ROOT'] . '/user/transact/perevod/all_res.php');
