<?
echo '<div class="side_ank">';
echo '<a class="link" href="' . homeLink() . '/faq">F.A.Q</a>
<a class="link" href="' . homeLink() . '/tooltips">Ключевые слова</a>
<a class="link" href="' . homeLink() . '/doska">Мошенники</a>
<a class="link" href="' . homeLink() . '/privacy">Политика конфиденциальности</a>';
echo '</div>';
