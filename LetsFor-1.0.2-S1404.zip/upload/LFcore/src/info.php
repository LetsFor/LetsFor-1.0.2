<?
$ver = '1.0.2';
$build = 'S1404252012';
$stade = 'stable';
