<?
echo '<div class="bar"></div>';
