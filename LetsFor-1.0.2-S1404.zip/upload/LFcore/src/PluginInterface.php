<?php
interface PluginInterface
{
    public function init();
}
