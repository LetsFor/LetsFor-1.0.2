<?
echo '<title>' . $LF_name . ' - ' . $LF_info . '</title>';
