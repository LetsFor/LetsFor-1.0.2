<?
if ($aut != 'Forum software by LetsFor™') {
    echo '<style>#loading-content { display: none; }</style>';
    echo '<div class="banner" style="margin-top: 15px;"><b style="font-size: 17px;">Смена копирайта является нарушением авторских прав</b>
<div class="opisanie-cpr" style="margin-top: 5px;">При изменении копирайта пользователь не может использовать LetsFor.</div></div>';
    echo '<center><span class="cpr" style="display: block">Forum software by LetsFor™ © 2024 - ' . date('Y') . ' LetsFor Community</span></center>';
}
