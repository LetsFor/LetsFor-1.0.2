<?
while ($a = mfa($post)) {
	require ($_SERVER['DOCUMENT_ROOT'] . '/LFcore/src/comment.php');
}
?>
