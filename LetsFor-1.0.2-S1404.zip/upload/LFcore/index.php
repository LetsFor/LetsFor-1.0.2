<?php
require_once('core.php');
header('Location: ' . homeLink() . '');
exit();
