<?php
require_once($_SERVER['DOCUMENT_ROOT'] . '/LFcore/core.php');
require_once($_SERVER['DOCUMENT_ROOT'] . '/admin/ip_search/all_res.php');
