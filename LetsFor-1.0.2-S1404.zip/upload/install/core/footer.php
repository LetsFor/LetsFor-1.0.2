<?
echo '<center>LetsFor-'.$ver.'-'.$stade.'</center>';
require_once ($_SERVER['DOCUMENT_ROOT'] . '/LFcore/scripts.php');
echo '</body>';
?>